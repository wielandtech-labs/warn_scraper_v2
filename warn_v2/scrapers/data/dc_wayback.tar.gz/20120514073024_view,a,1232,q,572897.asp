
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML LANG="en-us">
	<DSFHEADER>
	<!--stopindex-->
	<HEAD>
		<!-- 
			This site was built with PPT DSF Technology
		Dynamic Site Framework	(c) 1999-2012 PPT, Lancaster PA
		-->

		<meta http-equiv="content-type" content="text/html;charset=iso-8859-1">
		
		
		
		
		<meta NAME="rating" CONTENT="general">
		<meta name="IS" content="ok_trust">
		<meta NAME="distribution" CONTENT="global">
		<meta NAME="MS.LOCALE" LANG="en-us" CONTENT="EN-US">
		<meta NAME="generator" Content="OIT-DSF: PPT v2.1">
		<meta NAME="copyright" CONTENT="Enter your Company or Top-Level Office.">
		<meta NAME="alias" CONTENT="http://does.dc.gov/does/">
		<meta NAME="author" CONTENT="Enter your Company or Top-Level Office">
		<meta NAME="owner" Content="Content: Contact System Admin / Enter your Company or Top-Level Office">
		<meta NAME="robots" CONTENT="all">
		<meta NAME="revisit-after" CONTENT="15 days">
		<meta HTTP-EQUIV="reply-To" CONTENT="mainteditor@dc.gov">
		
		
		<title>DOES: Monthly WARN Notification Log</title>
			
		 
<style type='text/css'>
.hidden	{ display:none; }
</style>

<style type="text/css">
		BODY { 
			
			font-family: 'Arial,Helvetica,Geneva';
			font-size: 'x-small';
						BACKGROUND-COLOR: ##FFFFFF
			}
		
		A:LINK { color:  }
		
		A:VISITED { color:  }
		
		A:HOVER { color:  }
		
		A:ACTIVE { color:  }
		
		.pagecolor	{ background-color: ##FFFFFF }
		A.pageopposite { color: #ffffff }
		.schemecolor1 { background-color: ##6483C5 }
		.schemecolor2 { background-color: ##001864 }
		.textcolor1 { color: ##6483C5 }
		.textcolor2 { color: ##001864 }
		
		TD { 
			font-family: 'Arial,Helvetica,Geneva';
			font-size: 'x-small';
		}
.Page-Title
{
	COLOR: #001864;
	FONT-SIZE: 13.5pt;
	FONT-FAMILY: Arial;
	TEXT-DECORATION: none;
	font-weight: bold;
}

.content
{
    COLOR: #000000;
    FONT-SIZE: 10pt;
    FONT-FAMILY: Arial;
    TEXT-DECORATION: none
}

.nounder {FONT-FAMILY: arial, verdana, helvetica, sans-serif; TEXT-DECORATION: none}

.white {COLOR: #ffffff; TEXT-DECORATION: none;}

A.white:hover {COLOR: #ffffcc; TEXT-DECORATION: underline;}

.lblue {COLOR: #eaf4ff; TEXT-DECORATION: none}

A.lblue:hover {COLOR: #ffffcc; TEXT-DECORATION: underline}

.red {COLOR: #ff0000; TEXT-DECORATION: none}

.red1 {COLOR: #ff0000; TEXT-DECORATION: none}

A.red1:hover {COLOR: #001864; TEXT-DECORATION: none}

.blue  {COLOR: #001864; TEXT-DECORATION: none}

A.visited.blue  {COLOR: #001864; TEXT-DECORATION: none}

A:active.blue  {COLOR: #001864; TEXT-DECORATION: none}

A.blue:link  {COLOR: #001864; TEXT-DECORATION: none}

A.blue:hover {COLOR: #ff0000; TEXT-DECORATION: none}

.ured {COLOR: #ff0000; TEXT-DECORATION: underline;}

A.ured:hover {COLOR: #001864; TEXT-DECORATION: underline;}

.black {COLOR: #000000; TEXT-DECORATION: none;}

A.visited.black {COLOR: #000000; TEXT-DECORATION: none;}

A:active.black {COLOR: #000000; TEXT-DECORATION: none;}

A.black:hover {COLOR: #ff0000; TEXT-DECORATION: underline;}

.highlight {BACKGROUND-COLOR: #eaeaea;}

.ltblue {color: #9DAEE8; text-decoration: none;}

A.ltblue:hover {COLOR: #ffffcc; TEXT-DECORATION: underline;}

.searchBox {background-color: #B5C1E7; border-color: #B5C1E7 #B5C1E7 #001E7A; border-style: solid; border-bottom-width: 1px}

.navLink {color: #001F7C; text-decoration: none ; font-family: Arial, Verdana, Geneva; font-size: 11px; font-weight: bold}

A.navLink:hover {color: #CC0000; text-decoration: underline}

.widgetLinks {font-family: Verdana, Arial, Geneva; font-size: 10px; text-decoration: none}

A.widgetLinks:hover { color: #001E7A; text-decoration: underline}

.agencyTitle {
	color: #001864;
	font-family: Verdana;
	font-size: 18pt;
	font-weight: bold;
	line-height: 20pt;
}

A.white:visited {color: #FFFFFF;text-decoration: none;}

A.white:active {color: #FFFFFF;text-decoration: none;}

A.red:visited {COLOR: #FF0000; TEXT-DECORATION: none}

A.red:active {COLOR: #FF0000; TEXT-DECORATION: none}

A.red:link {COLOR: #FF0000; TEXT-DECORATION: none}

A.red:hover {COLOR: #001864; TEXT-DECORATION: underline}

.table-categories{font-family: arial;font-size: 10pt;color: #FFFFFF;font-weight: bold;background-color: #83A0C8;}

.table-row1 {font-family: arial;font-size: 10pt;color: #000000;background-color: #FFFFFF;}

.table-row2 {font-family: arial;font-size: 10pt;color: #000000;background-color: #E1ECF2;}

A:link {text-decoration: none;}

A:visited {text-decoration:none;}

A:hover {COLOR:#000000; TEXT-DECORATION: underline;}

A:active {text-decoration:none;}

A:unknown {COLOR: #ffffcc; TEXT-DECORATION: underline;}

.navtax {font-family: Arial, Geneva; font-size: 10px; color: #FFFFFF; text-decoration: none}

.navtax:hover {font-family: Arial, Geneva; font-size: 10px; color: #FFFFCC; text-decoration: underline}

.taxsubnav {font-family: Verdana, Arial, Geneva; font-size: 9px; color: #eaf4ff; text-decoration: none}
   
.taxsubnav:hover {font-family: Arial, Geneva; font-size: 9px; color: #FFFFCC; text-decoration: underline}

.footer a, .footer a:link, .footer a:visited {color:#001864; text-decoration:none; font:normal 10px arial;}

.footer a:hover {color:#001864; text-decoration:none}


</style>
</head>
<a href="#navskip"><img class=hidden src=../assets/images/spacer.gif height=0 border=0 alt='Skip to main content'></a>
	
<a name='top'>
<BODY text="#000000" vLink="#000080" link="#1e90ff" bgColor="#ffffff" leftMargin="0" topMargin="0" MARGINWIDTH="0" MARGINHEIGHT="0">
<LINK href="../assets/templates/30/inc/main2.css" rel="stylesheet" type="text/css">
	<A href="#navskip"><IMG class=hidden height=0 alt="Skip to main content" src="../assets/images/spacer.gif" border=0></A> 
<DIV id=tooltip onmouseover=clearTimeout(TimerID) style="Z-INDEX: 10; VISIBILITY: hidden; POSITION: absolute" onmouseout=showMenu(0)></DIV>
<TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
<SCRIPT language=javascript id=wl_base>
var wl_url = ""; // The standard WorldLingo translation link (justappend//the escaped FULL destination url)  
var wl_burl = ""; // The standard WorldLingo translation link with//baseHref included  
var wl_ourl = ""; // The original page that has been translated  
var wl_rurl = ""; // The previous page that the user viewed  
var wl_srclang = ""; // The source lang (ie EN) for this translation  
var wl_srclanguage = ""; // The source language (ie English) for this//translation  
var wl_trglang = ""; // The target lang (ie EN) for this translation  
var wl_trglanguage = ""; // The target language (ie English) for this //translation</SCRIPT>

<SCRIPT language=JavaScript src="/vincludes/globalP.asp" wl_replace="attrib=src,IT=/vincludes/global_it.asp,ES=/vincludes/global_es.asp,EN=/vincludes/global.asp,FR=/vincludes/global_fr.asp,PT=/vincludes/global_br.asp,DE=/vincludes/global_de.asp,NL=/vincludes/global_nl.asp,EL=/vincludes/global_gre.asp"></SCRIPT>

<TBODY>
<TR>
<TD width=215><A title="DC Home" href="http://www.dc.gov"><IMG alt="DC Home" src="../assets/templates/30/images/topnav-logo.gif" border=0></A></TD>
<TD width=1 bgColor=#ffffff><IMG alt="" src="../assets/templates/30/images/dot.gif"></TD>
<TD><A id=test6 onmouseover="showMenu(1, 'drop6', getAnchorX('test6'), 18)" title="Mayor Fenty" onmouseout=showMenu(0) href="http://dc.gov/mayor/index.shtm?portal_link=h" target=_top name=test6><IMG height=18 alt="Mayor Fenty" src="../assets/templates/30/images/nav_mayor.jpg" width=112 border=0></A></TD>
<TD width=1 bgColor=#ffffff><IMG alt="" src="../assets/templates/30/images/dot.gif"></TD>
<TD width=102><A id=test1 onmouseover="showMenu(1, 'drop1', getAnchorX('test1'), 18)" title="DC Guide" onmouseout=showMenu(0) href="http://about.dc.gov/index.asp?portal_link=h" target=_top name=test1><IMG height=18 alt="DC Guide" src="../assets/templates/30/images/nav_about.jpg" width=102 border=0></A></TD>
<TD width=1 bgColor=#ffffff><IMG alt="" src="../assets/templates/30/images/dot.gif"></TD>
<TD width=112><A id=test2 onmouseover="showMenu(1, 'drop2', getAnchorX('test2'), 18)" title=Residents onmouseout=showMenu(0) href="http://rrc.dc.gov/?portal_link=h" target=_top name=test2><IMG height=18 alt=Residents src="../assets/templates/30/images/nav_residents.jpg" width=112 border=0></A></TD>
<TD width=1 bgColor=#ffffff><IMG alt="" src="../assets/templates/30/images/dot.gif"></TD>
<TD width=112><A id=test3 onmouseover="showMenu(1, 'drop3', getAnchorX('test3'), 18)" title=Business onmouseout=showMenu(0) href="http://brc.dc.gov/index.asp?portal_link=h" target=_top name=test3><IMG height=18 alt=Business src="../assets/templates/30/images/nav_business.jpg" width=112 border=0></A></TD>
<TD width=1 bgColor=#ffffff><IMG alt="" src="../assets/templates/30/images/dot.gif"></TD>
<TD width=112><A id=test4 onmouseover="showMenu(1, 'drop4', getAnchorX('test4'), 18)" title=Visitors onmouseout=showMenu(0) href="http://vrc.dc.gov/?portal_link=h" target=_top name=test4><IMG height=18 alt=Visitors src="../assets/templates/30/images/nav_visitors.jpg" width=112 border=0></A></TD>
<TD width=1 bgColor=#ffffff><IMG alt="" src="../assets/templates/30/images/dot.gif"></TD>
<TD width=112><A id=test5 onmouseover="showMenu(1, 'drop5', getAnchorX('test5'), 18)" title="District of Columbia Government" onmouseout=showMenu(0) href="http://grc.dc.gov/?portal_link=h" target=_top name=test5><IMG height=18 alt="DC Government" src="../assets/templates/30/images/nav_dcgov.jpg" width=112 border=0></A></TD>
<TD width=1 bgColor=#ffffff><IMG alt="" src="../assets/templates/30/images/dot.gif"></TD>
<TD width=108><A title=Kids href="http://kids.dc.gov"><IMG height=18 alt=Kids src="../assets/templates/30/images/nav_kids.jpg" width=108 border=0></A></TD>
<TD width=1 bgColor=#ffffff><IMG alt="" src="../assets/templates/30/images/dot.gif"></TD>
<TD width="100%" bgColor=#10447e></TD></TR></TBODY></TABLE>
		<TABLE cellSpacing=0 cellPadding=0 width=600 border=0>
		<TBODY>
			<TR>
				<TD vAlign=top align=left width=10 bgColor=#3253bb><IMG height=1 alt=" " src="../Assets/templates/30/img2/dot.gif" width=10 border=0><BR></TD><!-- Modify Template Page Name Here -->
				<TD vAlign=center align=left width=550 bgColor=#3253bb ?nowrap?><FONT face=Arial color=#ffffff size=4><B>Department of Employment Services</B></FONT><BR></TD>
				<TD vAlign=top align=left width=240 background=../Assets/templates/30/img2/grad_bar1.gif bgColor=#ffffff><IMG height=25 alt=" " src="../Assets/templates/30/img2/grad_bar.gif" width=67 border=0><BR></TD></TR></TBODY></TABLE>
	
<!--startindex-->
</DSFHEADER>

<DSFNAV><!--stopindex-->


<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
	<!-- LEFT NAV start-->
  <td valign="top" width="124" bgcolor="#001864">
	<table border="0" cellspacing="0" cellpadding="0" width="124">
	  <tr>
		<td width="5"><img src="../assets/templates/30/images/spacer.gif" width="5" height="10" alt=""></td>
		<td valign="top" width="119"><img src="../assets/templates/30/images/dot.gif" width="1" height="1" alt=""></td>
	  </tr>
		
	  <tr>
		<td><img src="../assets/templates/30/images/dot.gif" width="1" height="1" alt=""></td>
		<td valign="top">
		
		  <!-- TAXONOMY STARTS HERE -->
		  
		  <table border="0" cellspacing="0" cellpadding="0" width="120">
			<tr>
			  <td valign="top" height="2"></td>
			  <td valign="top" width="120" height="2">
			

<SCRIPT language="javascript"> 
function SwapImg_doesNav(ImgID_str, Url_str, fheight_int, fwidth_int){
		document.images[ImgID_str].src = Url_str;
		document.images[ImgID_str].height = fheight_int;
		document.images[ImgID_str].width = fwidth_int;
		}
</SCRIPT>

<TABLE border="0" cellpadding="0" cellspacing="0" valign="top"><TR><TD valign="top" align="left" nowrap><a href="/does/cwp/view.asp?a=1232&q=572897&doesNav=|32060|"><IMG name="32060" src="/does/Assets/Templates/30/images/bul_dot.gif" height="1" width="1" border="0" alt="View sub-links" ></a></td><td valign="middle"><A name="32060" href="/does/site/default.asp?doesNav=|32060|"  class="navtax"><FONT FACE='verdana'><b>DOES HOME</b><br></font></A></Td></Tr><TR><TD valign="top" align="left" nowrap><IMG src="/does/Assets/Templates/30/images/bul_dot_sub.gif" height="1" width="1" border="0" alt='' ></td><td valign="middle">&nbsp;</Td></Tr><TR><TD valign="top" align="left" nowrap><a href="/does/cwp/view.asp?a=1232&q=572897&doesNav=|32062|"><IMG name="32062" src="/does/Assets/Templates/30/images/bul_dot.gif" height="1" width="1" border="0" alt="View sub-links" ></a></td><td valign="middle"><A name="32062" href="/does/cwp/view,a,1232,q,537715,doesNav,|32062|,.asp"  class="navtax"><FONT FACE='verdana'><b>SERVICES</b></font><br></A></Td></Tr><TR><TD valign="top" align="left" nowrap><IMG src="/does/Assets/Templates/30/images/bul_dot_sub.gif" height="1" width="1" border="0" alt='' ></td><td valign="middle">&nbsp;</Td></Tr><TR><TD valign="top" align="left" nowrap><a href="/does/cwp/view.asp?a=1232&q=572897&doesNav=|32064|"><IMG name="32064" src="/does/Assets/Templates/30/images/bul_dot.gif" height="1" width="1" border="0" alt="View sub-links" ></a></td><td valign="middle"><A name="32064" href="/does/cwp/view,a,1233,q,538338,doesNav,|32064|,.asp"  class="navtax"><FONT FACE='verdana'><b>INFORMATION</b></font></A></Td></Tr><TR><TD valign="top" align="left" nowrap><IMG src="/does/Assets/Templates/30/images/bul_dot_sub.gif" height="1" width="1" border="0" alt='' ></td><td valign="middle">&nbsp;</Td></Tr><TR><TD valign="top" align="left" nowrap><IMG src="/does/Assets/Templates/30/images/bul_dot_sub.gif" height="1" width="1" border="0" alt='' ></td><td valign="middle"><A name="32066" href="http://aboutdcgov.dc.gov/DC/About+DC.Gov/Feedback"  class="navtax"><FONT FACE='verdana'><b>ONLINE SERVICE<br>��REQUESTS</b></font></A></Td></Tr></table>
			  </td>
			</tr>
		  </table>
		  
		  <!-- TAXONOMY ENDS HERE -->
		&nbsp;&nbsp;
<SCRIPT language=javascript>
//
// Optional verification function. To avoid using it remove "onsubmit" attribute from the "<form..." tag below
//
function verifyQuery(oForm) {
	var oText;
	if (oForm)
		if (oText = oForm.query) {
			var strQuery = oText.value;
			var reNonSpace = /\S/g;
			if (reNonSpace.test(strQuery)) {
				return true;
			} else {
				alert("Please enter a question and click 'Go'.");
				oText.focus();
				return false;
			}
		}
	return true;
}

</SCRIPT>
 
<FORM name=querybox onsubmit="javascript: return verifyQuery(this);" action=http://google.dc.gov/search method=get><INPUT class=jeevesBox style="WIDTH: 83px; HEIGHT: 22px" size=11 name=q> <INPUT type=image alt=Search src="/does/lib/does/google/ask_blue.gif" border=0><INPUT type=hidden value=xml_no_dtd name=output> <INPUT type=hidden value=UTF-8 name=oe> <INPUT type=hidden value=UTF-8 name=ie> <INPUT type=hidden value=dc_v2 name=client> <INPUT type=hidden value=dc_v2 name=proxystylesheet>&nbsp; <INPUT type=hidden value=does_crb name=site><INPUT type=hidden value=0 name=filter> </FORM>

		</td>
	  </tr>
	  <!-- Login starts here -->
	  <tr>
		<td height="15"><img src='../assets/templates/30/images/dot.gif' width='1' height='1' alt=''></td>
		<td><img src='../assets/templates/30/images/dot.gif' width='1' height='1' alt=''></td>
	  </tr>
	<!--  <tr>
		<td></td>
		<td>
		  <table border="0" cellspacing="0" cellpadding="0">
			<tr>
			  <td valign="top" width="12"><img src='../assets/templates/30/bullets/bul_dot_sub.gif' width='10' height='12' alt=''></td>
			  <td valign="top" nowrap></td>
			</tr>
		  </table>
		</td>
	  </tr>
	  <tr>
		<td></td>
		<td></td>
	  </tr>-->
	  <!-- login ends here -->
	  <!-- site admin link start-->
	  <tr> 
		<td height="10"><img src="../assets/templates/30/images/dot.gif" width="1" height="1" alt=""></td>
		<td><img src="../assets/templates/30/images/dot.gif" width="1" height="1" alt=""></td>
	  </tr>
	  <tr> 
		<td></td>
		<td>
		  <table border="0" cellspacing="0" cellpadding="0">
			<tr>
			  <td valign="top" width="12"><img src='../assets/templates/30/bullets/bul_dot_sub.gif' width='10' height='12' alt=''></td>
			  <td valign="top"><font face="Arial, Verdana, Geneva" size="1">
			  
			  </td>
			</tr>
			<tr> 
				<td height="10"><img src="../assets/templates/30/images/dot.gif" width="1" height="1" alt=""></td>
				<td><img src="../assets/templates/30/images/dot.gif" width="1" height="1" alt=""></td>
			</tr>
			<tr>
				<td></td>
				<td></td>
			</tr>
		  </table>
		</td>
	  </tr>
	  <tr>
		<td></td>
		<td></td>
	  </tr>
	  <!-- site admin link end -->
	  
	</table>
  </td>
  <!-- LEFT NAV END -->
	<td></td>
	<td valign="top">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td valign="top">
					<table border="0" cellspacing="0" cellpadding="10">
						<tr>
							<td width="100%">
								<!--content start-->
	<!--startindex-->
	</DSFNAV><a name="navskip"></a>
	<DSFCONTENT ID="6279" NAME="does" ABBREV="DOES" TITLE="Department of Employment Services" CONTACT="mainteditor@dc.gov" uuid="18431982-D38C-4071-9654-384F98D0FFDB">
   <font face='Arial,Helvetica,Geneva' size='4' color=#001864><b><!-- <DSFAPP id=1232>SERVICES</DSFAPP> -->
<!-- <DSFCONTENTCATEGORY id=44509 uuid="CBA16781-3CE3-4013-AF1A-1B02B1186286">Services Category</DSFCONTENTCATEGORY> --></b></font>
<P>
<!-- <DSFCONTENTTAGLINE id=572897></DSFCONTENTTAGLINE> --><FONT face='Arial,Helvetica,Geneva' size='2'>
<DSFCONTENTBODY id=572897 uuid="B0DD4276-A29F-409B-8ACB-F3185525C341"><DIV align=left><SPAN><FONT color=#001864 size=4><STRONG>Rapid Response Event Log<BR><BR></STRONG></FONT></SPAN><STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</STRONG> </DIV>
<DIV>
<TABLE id=StdTable style="WIDTH: 644px; HEIGHT: 958px" cellSpacing=1 cellPadding=2 width=644 border=0>
<TBODY>
<TR class=header bgColor=#83a0c8>
<TD><FONT color=#ffffff size=2><B contentEditable=true>
<DIV align=left><FONT size=2>Notice<BR>Date</FONT></DIV></B></FONT></TD>
<TD><FONT color=#ffffff size=2><B contentEditable=true>Agency/Organization</B></FONT></TD>
<TD><FONT color=#ffffff size=2><B contentEditable=true>
<DIV align=left><FONT size=2>Number of<BR>Employees<BR>Affected</FONT></DIV></B></FONT></TD>
<TD><FONT color=#ffffff size=2><B contentEditable=true>
<DIV align=left><FONT size=2>Effective<BR>Layoff&nbsp;Date</FONT></DIV></B></FONT></TD>
<TD><FONT color=#ffffff size=2><B contentEditable=true>
<DIV align=left><FONT size=2>Type*<BR>Code</FONT></DIV></B></FONT></TD></TR>
<TR>
<TR>
<TR>
<TD class=table-row2><STRONG>January</STRONG></TD>
<TD class=table-row2></TD>
<TD class=table-row2></TD>
<TD class=table-row2></TD>
<TD class=table-row2></TD></TR>
<TR>
<TD>01/11/12</TD>
<TD>DC Department of Health</TD>
<TD>18</TD>
<TD></TD>
<TD>2</TD></TR>
<TR>
<TD class=table-row2><STRONG class=table-row2>November</STRONG></TD>
<TD class=table-row2></TD>
<TD class=table-row2></TD>
<TD class=table-row2></TD>
<TD class=table-row2></TD></TR>
<TR>
<TD>11/21/11</TD>
<TD>Filene's Basement/Syms Clothing</TD>
<TD>201</TD>
<TD></TD>
<TD>2</TD></TR>
<TR>
<TD class=table-row2><STRONG>October</STRONG></TD>
<TD class=table-row2></TD>
<TD class=table-row2></TD>
<TD class=table-row2></TD>
<TD class=table-row2></TD></TR>
<TR>
<TD>10/12/11</TD>
<TD>Tourmobile Sightseeing</TD>
<TD>112</TD>
<TD></TD>
<TD>2</TD></TR>
<TR>
<TD class=table-row2><STRONG class=table-row2>September</STRONG></TD>
<TD class=table-row2></TD>
<TD class=table-row2></TD>
<TD class=table-row2></TD>
<TD class=table-row2></TD></TR>
<TR>
<TD>09/28/11</TD>
<TD>Defenders of Wildlife</TD>
<TD>14</TD>
<TD></TD>
<TD>1</TD></TR>
<TR>
<TD class=table-row2>09/21/11</TD>
<TD class=table-row2>DC Child and Family Services Agency</TD>
<TD class=table-row2>8</TD>
<TD class=table-row2></TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD>09/21/11</TD>
<TD>DC Metropolitan Police Department</TD>
<TD>15</TD>
<TD></TD>
<TD>1</TD></TR>
<TR>
<TD class=table-row2>09/13/11</TD>
<TD class=table-row2>WSI</TD>
<TD class=table-row2>45</TD>
<TD class=table-row2></TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD>09/07/11</TD>
<TD>DC Office of Contracting and Procurement</TD>
<TD>40</TD>
<TD></TD>
<TD>1</TD></TR>
<TR>
<TD class=table-row2>09/07/11</TD>
<TD class=table-row2>DC Department of Public Works</TD>
<TD class=table-row2>51</TD>
<TD class=table-row2></TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD><STRONG>August</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR>
<TD class=table-row2></TD>
<TD class=table-row2>Science Applications International Corporation</TD>
<TD class=table-row2>80</TD>
<TD class=table-row2></TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD></TD>
<TD>Tourmobile Sightseeing</TD>
<TD>112</TD>
<TD></TD>
<TD>2</TD></TR>
<TR>
<TD class=table-row2></TD>
<TD class=table-row2>Lockheed Martin Electronic Systems Global Training and Logistic</TD>
<TD class=table-row2>5</TD>
<TD class=table-row2></TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD></TD>
<TD>U.S. Dept. of the Interior Bureau of Ocean Energy Management</TD>
<TD>15</TD>
<TD></TD>
<TD>1</TD></TR>
<TR>
<TD class=table-row2><STRONG>July</STRONG></TD>
<TD class=table-row2></TD>
<TD class=table-row2></TD>
<TD class=table-row2></TD>
<TD class=table-row2></TD></TR>
<TR>
<TD>07/05/11</TD>
<TD>Capitol City Brewing Company</TD>
<TD>90</TD>
<TD></TD>
<TD>2</TD></TR>
<TR>
<TD class=table-row2><STRONG>June</STRONG></TD>
<TD class=table-row2></TD>
<TD class=table-row2></TD>
<TD class=table-row2></TD>
<TD class=table-row2></TD></TR>
<TR>
<TD>06/22/11</TD>
<TD>A&amp;P (Super Fresh)</TD>
<TD>57</TD>
<TD></TD>
<TD>1</TD></TR>
<TR>
<TD class=table-row2></TD>
<TD class=table-row2>RTS (Verizon Wireless)</TD>
<TD class=table-row2>11</TD>
<TD class=table-row2></TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD><STRONG>May</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR>
<TD class=table-row2>05/04/11</TD>
<TD class=table-row2>Walter Reed Army Medical Center</TD>
<TD class=table-row2>150</TD>
<TD class=table-row2></TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD><STRONG>March</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR>
<TD class=table-row2>3/25&amp;29/2011</TD>
<TD class=table-row2>Howrey, LLP</TD>
<TD class=table-row2>427</TD>
<TD class=table-row2></TD>
<TD class=table-row2>2</TD></TR>
<TR>
<TD><STRONG>January</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR>
<TD class=table-row2>01/04/11</TD>
<TD class=table-row2>U.S. Department of Energy/ BP Oil Commission</TD>
<TD class=table-row2>30</TD>
<TD class=table-row2></TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD><STRONG>December</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR>
<TD class=table-row2>12/06/10</TD>
<TD class=table-row2>U.S.House of Representatives</TD>
<TD class=table-row2>400</TD>
<TD class=table-row2></TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD>12/06/10</TD>
<TD>U.S. Senate</TD>
<TD>250</TD>
<TD></TD>
<TD>1</TD></TR>
<TR>
<TD class=table-row2><STRONG class=table-row2>September</STRONG></TD>
<TD class=table-row2></TD>
<TD class=table-row2></TD>
<TD class=table-row2></TD>
<TD class=table-row2></TD></TR>
<TR>
<TD>09/24/10</TD>
<TD>Computer Sciences Corporation</TD>
<TD>47</TD>
<TD></TD>
<TD>1</TD></TR>
<TR>
<TD class=table-row2>09/21/10</TD>
<TD class=table-row2>US Department of Energy</TD>
<TD class=table-row2>5</TD>
<TD class=table-row2></TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD><STRONG>July</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR>
<TD class=table-row2>07/19/10</TD>
<TD class=table-row2>Wackenhut Services Incorporated</TD>
<TD class=table-row2>73</TD>
<TD class=table-row2></TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD><STRONG>June</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR>
<TD class=table-row2>06/16/10</TD>
<TD class=table-row2>ESPN Sport Zone</TD>
<TD class=table-row2>152</TD>
<TD class=table-row2></TD>
<TD class=table-row2>2</TD></TR>
<TR>
<TD><STRONG>May</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR>
<TD class=table-row2>05/14/10</TD>
<TD class=table-row2>VMT Long Term Care Management, Inc</TD>
<TD class=table-row2>400</TD>
<TD class=table-row2></TD>
<TD class=table-row2>2</TD></TR>
<TR>
<TD><STRONG>April</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR>
<TD class=table-row2>04/13/10</TD>
<TD class=table-row2>Central Parking</TD>
<TD class=table-row2>149</TD>
<TD class=table-row2></TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD><STRONG>January</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR>
<TD class=table-row2>01/15/10</TD>
<TD class=table-row2>Allied Capital</TD>
<TD class=table-row2>91</TD>
<TD class=table-row2></TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD><STRONG>December</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR>
<TD class=table-row2>N/A</TD>
<TD class=table-row2>Allied Capital</TD>
<TD class=table-row2>91</TD>
<TD class=table-row2></TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD>12/09/09</TD>
<TD>Washington Times</TD>
<TD>400</TD>
<TD>12/09-10/09</TD>
<TD>1</TD></TR>
<TR>
<TD class=table-row2><STRONG class=table-row2>October</STRONG></TD>
<TD class=table-row2></TD>
<TD class=table-row2></TD>
<TD class=table-row2></TD>
<TD class=table-row2></TD></TR>
<TR>
<TD>10/30/09</TD>
<TD>Citi Bank</TD>
<TD>11</TD>
<TD></TD>
<TD>1</TD></TR>
<TR>
<TD><STRONG class=table-row2>September</STRONG></TD>
<TD class=table-row2></TD>
<TD class=table-row2></TD>
<TD class=table-row2></TD>
<TD class=table-row2></TD></TR>
<TR>
<TD>09/30/09</TD>
<TD>Office of the Attorney General</TD>
<TD>10</TD>
<TD></TD>
<TD>1</TD></TR>
<TR>
<TD class=table-row2>09/30/09</TD>
<TD class=table-row2>Ombudsman for Public Education</TD>
<TD class=table-row2>1</TD>
<TD class=table-row2></TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD>09/24/09</TD>
<TD>Office of Tenant Advocate</TD>
<TD>6</TD>
<TD></TD>
<TD>1</TD></TR>
<TR>
<TD class=table-row2>09/24/09</TD>
<TD class=table-row2>Department of Motor Vehicles</TD>
<TD class=table-row2>6</TD>
<TD class=table-row2></TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD>09/23/09</TD>
<TD>DC Sports and Entertainment Commission</TD>
<TD>20</TD>
<TD></TD>
<TD>2</TD></TR>
<TR>
<TD class=table-row2>09/03/09</TD>
<TD class=table-row2>DC Department of Health Care Finance</TD>
<TD class=table-row2>80</TD>
<TD class=table-row2></TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD>09/03/09</TD>
<TD>DC National Guard</TD>
<TD>1</TD>
<TD></TD>
<TD>1</TD></TR>
<TR>
<TD class=table-row2>09/02/09</TD>
<TD class=table-row2>DC Office of Chief Medical Examiner</TD>
<TD class=table-row2>3</TD>
<TD class=table-row2></TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD><STRONG>August</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR>
<TD class=table-row2>08/25/09</TD>
<TD class=table-row2>DC Public Schools Office of&nbsp; Facilities Modernization</TD>
<TD class=table-row2>50</TD>
<TD class=table-row2></TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD>08/07/09</TD>
<TD>DC Department of Parks and Recreation</TD>
<TD>100</TD>
<TD></TD>
<TD>1</TD></TR>
<TR>
<TD class=table-row2>08/07/09</TD>
<TD class=table-row2>DC Homeland Security and Emergency Management</TD>
<TD class=table-row2>2</TD>
<TD class=table-row2></TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD>08/07/09</TD>
<TD>DC Department of Consumer and Regulatory Affairs</TD>
<TD>2</TD>
<TD></TD>
<TD>1</TD></TR>
<TR>
<TD class=table-row2>08/07/09</TD>
<TD class=table-row2>DC Department of Motor Vehicles</TD>
<TD class=table-row2>1</TD>
<TD class=table-row2></TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD>08/07/09</TD>
<TD>DC Office of Planning</TD>
<TD>5</TD>
<TD></TD>
<TD>1</TD></TR>
<TR>
<TD class=table-row2>08/07/09</TD>
<TD class=table-row2>DC Department of Health </TD>
<TD class=table-row2>80</TD>
<TD class=table-row2></TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD><STRONG>July</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR>
<TD class=table-row2>07/23/09</TD>
<TD class=table-row2>DC Department of Transportation</TD>
<TD class=table-row2>65</TD>
<TD class=table-row2>07/31/09</TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD>07/22/09</TD>
<TD>Southeastern University</TD>
<TD>20</TD>
<TD>07/31/09</TD>
<TD>1</TD></TR>
<TR>
<TD class=table-row2>07/07/09</TD>
<TD class=table-row2>DC Department of Mental Health</TD>
<TD class=table-row2>120</TD>
<TD class=table-row2>07/31/09</TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD><STRONG>June</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR>
<TD class=table-row2>06/10/09</TD>
<TD class=table-row2>Balducci's Food Market</TD>
<TD class=table-row2>86</TD>
<TD class=table-row2>06/30/09</TD>
<TD class=table-row2>2</TD></TR>
<TR>
<TD>06/10/09</TD>
<TD>Office of Partnership and Grant Services</TD>
<TD>1</TD>
<TD></TD>
<TD>1</TD></TR>
<TR>
<TD class=table-row2>06/10/09</TD>
<TD class=table-row2>Department on Disability Services</TD>
<TD class=table-row2>5</TD>
<TD class=table-row2></TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD>06/10/09</TD>
<TD>DC Department of Human Services </TD>
<TD></TD>
<TD></TD>
<TD>1</TD></TR>
<TR>
<TD class=table-row2><STRONG>May</STRONG></TD>
<TD class=table-row2></TD>
<TD class=table-row2></TD>
<TD class=table-row2></TD>
<TD class=table-row2></TD></TR>
<TR>
<TD>05/13/09</TD>
<TD>Child and Family Services Agency</TD>
<TD></TD>
<TD></TD>
<TD>1</TD></TR>
<TR>
<TD class=table-row2><STRONG>April</STRONG></TD>
<TD class=table-row2></TD>
<TD class=table-row2></TD>
<TD class=table-row2></TD>
<TD class=table-row2></TD></TR>
<TR>
<TD>04/30/09</TD>
<TD>Department of Parks and Recreation</TD>
<TD>18</TD>
<TD></TD>
<TD>1</TD></TR>
<TR>
<TD class=table-row2>04/23/09</TD>
<TD class=table-row2>Office of Labor Relations and Collective Bargaining</TD>
<TD class=table-row2>1</TD>
<TD class=table-row2></TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD>04/23/09</TD>
<TD>Office of Public Education Facilities Modernization</TD>
<TD>2</TD>
<TD></TD>
<TD>1</TD></TR>
<TR>
<TD class=table-row2>04/23/09</TD>
<TD class=table-row2>Department of Motor Vehicles</TD>
<TD class=table-row2>4</TD>
<TD class=table-row2></TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD>04/23/09</TD>
<TD>Office of Risk Management</TD>
<TD>3</TD>
<TD></TD>
<TD>1</TD></TR>
<TR>
<TD class=table-row2>04/23/09</TD>
<TD class=table-row2>Office of Contracting and Procurement</TD>
<TD class=table-row2>6</TD>
<TD class=table-row2></TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD>04/23/09</TD>
<TD>Office on Human Rights</TD>
<TD>1</TD>
<TD></TD>
<TD>1</TD></TR>
<TR>
<TD class=table-row2>04/23/09</TD>
<TD class=table-row2>The Taxicab Commission</TD>
<TD class=table-row2>1</TD>
<TD class=table-row2></TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD>04/23/09</TD>
<TD>DCTV/Office of Cable Television</TD>
<TD>5</TD>
<TD></TD>
<TD>1</TD></TR>
<TR>
<TD class=table-row2>04/01/09</TD>
<TD class=table-row2>Fried Frank, LLP</TD>
<TD class=table-row2>20</TD>
<TD class=table-row2></TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD><STRONG>February</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR>
<TD class=table-row2>02/03/09</TD>
<TD class=table-row2>Gannet News Services</TD>
<TD class=table-row2>57</TD>
<TD class=table-row2></TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD><STRONG>January</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR>
<TD class=table-row2>01/22/09</TD>
<TD class=table-row2>DC Office of the Attorney General</TD>
<TD class=table-row2>3</TD>
<TD class=table-row2></TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD><STRONG>December</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR>
<TD class=table-row2>12/2008</TD>
<TD class=table-row2>US General Services Administration</TD>
<TD class=table-row2>75</TD>
<TD class=table-row2>12/18/08</TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD>12/2008</TD>
<TD>US Department of the Interior</TD>
<TD>50</TD>
<TD>12/17/08</TD>
<TD>1</TD></TR>
<TR>
<TD class=table-row2>12/2008</TD>
<TD class=table-row2>US Department of Labor</TD>
<TD class=table-row2>50</TD>
<TD class=table-row2>12/12/08</TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD><STRONG>November</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR>
<TD class=table-row2>11/17/08</TD>
<TD class=table-row2>Fried Frank, LLP</TD>
<TD class=table-row2>15</TD>
<TD class=table-row2>11/20/08</TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD><STRONG>October</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR>
<TD class=table-row2>10/24/08</TD>
<TD class=table-row2>US Department of Transportation</TD>
<TD class=table-row2>110</TD>
<TD class=table-row2>11/19/08</TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD>10/24/08</TD>
<TD>US Department of Housing &amp; Urban Development</TD>
<TD>110</TD>
<TD>11/13/08</TD>
<TD>1</TD></TR>
<TR>
<TD class=table-row2>10/23/08</TD>
<TD class=table-row2>Gate Gourmet, Inc.</TD>
<TD class=table-row2>122</TD>
<TD class=table-row2></TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD>10/22/08</TD>
<TD>US Department of Commerce</TD>
<TD>150</TD>
<TD>11/21/08</TD>
<TD>1</TD></TR>
<TR>
<TD class=table-row2>10/17/08</TD>
<TD class=table-row2>US Department of Energy</TD>
<TD class=table-row2>50</TD>
<TD class=table-row2>11/14/08</TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD>10/2008</TD>
<TD>Executive Office of the President</TD>
<TD>500</TD>
<TD>12/3/08</TD>
<TD>1</TD></TR>
<TR>
<TD class=table-row2>10/2008</TD>
<TD class=table-row2>US Department of Education</TD>
<TD class=table-row2>70</TD>
<TD class=table-row2>12/5/08</TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD>10/3/08</TD>
<TD>Revolution Health Group</TD>
<TD>47</TD>
<TD></TD>
<TD>1</TD></TR>
<TR>
<TD><STRONG class=table-row2>September</STRONG></TD>
<TD class=table-row2></TD>
<TD class=table-row2></TD>
<TD class=table-row2></TD>
<TD class=table-row2></TD></TR>
<TR>
<TD>9/26/08</TD>
<TD>Heller Ehrman, LLP</TD>
<TD>98</TD>
<TD></TD>
<TD>2</TD></TR>
<TR>
<TD class=table-row2>9/2008</TD>
<TD class=table-row2>US Department of Agriculture</TD>
<TD class=table-row2>105</TD>
<TD class=table-row2>12/3/08</TD>
<TD class=table-row2>1</TD></TR>
<TR>
<TD>9/2008</TD>
<TD>US House of Representatives</TD>
<TD>456</TD>
<TD>12/4/08</TD>
<TD>1</TD></TR>
<TR>
<TD class=table-row2><STRONG>August</STRONG></TD>
<TD class=table-row2></TD>
<TD class=table-row2></TD>
<TD class=table-row2></TD>
<TD class=table-row2></TD></TR>
<TR>
<TD>08/21/08</TD>
<TD>Jurys Washington Hotel</TD>
<TD>175</TD>
<TD>9/11/2008</TD>
<TD>1</TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD>08/05/08</TD>
<TD>The Washington Times</TD>
<TD>70</TD>
<TD>08/15/19/28/08</TD>
<TD>1</TD></TR>
<TR>
<TR>
<TD>08/06/08</TD>
<TD>DC Department of Health</TD>
<TD>25</TD>
<TD>08/27/08</TD>
<TD>1</TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD>08/06/08</TD>
<TD>DC Dept. of Youth Rehabilitation Services</TD>
<TD>25</TD>
<TD>08/27/08</TD>
<TD>1</TD></TR>
<TR>
<TR>
<TD><STRONG>March </STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD>03/06/08</TD>
<TD>American Institute for Cancer Research </TD>
<TD>4</TD>
<TD>N/A</TD>
<TD>1</TD></TR>
<TR>
<TD>03/14/08</TD>
<TD>American Red Cross National Headquarters </TD>
<TD>408</TD>
<TD>04/25/28/30 and 05/02/08</TD>
<TD>1</TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD>03/16/08</TD>
<TD>Bureau of Rehabilitation </TD>
<TD>20</TD>
<TD>03/18/08</TD>
<TD>2</TD></TR>
<TR>
<TD><STRONG>January </STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD>01/31/08</TD>
<TD>DC Department of Human Resources</TD>
<TD>8</TD>
<TD>02/07/08</TD>
<TD>1</TD></TR>
<TR>
<TD>01/31/08</TD>
<TD>Washington Gas</TD>
<TD>1</TD>
<TD>02/13/08</TD>
<TD>1</TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD><STRONG>December</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR>
<TD>12/10/07</TD>
<TD>MVM, &nbsp;Inc.</TD>
<TD>51</TD>
<TD>1/31/08</TD>
<TD>2</TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR>
<TD><STRONG>November</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD>11/14/07</TD>
<TD>Dewey &amp; LeBeouf, LPP</TD>
<TD>20</TD>
<TD>01/11/08 &amp; 01/31/08</TD>
<TD>1</TD></TR>
<TR>
<TD>11/14/07</TD>
<TD>Resources for Human Development, Inc.</TD>
<TD>20</TD>
<TD>1/31/08</TD>
<TD>2</TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD>11/14/07</TD>
<TD>Capitol Health Management Services, LCC</TD>
<TD>25</TD>
<TD>11/30/07</TD>
<TD>1</TD></TR>
<TR>
<TD>11/19/07</TD>
<TD>Washington Gas</TD>
<TD>2</TD>
<TD>1/18/2008</TD>
<TD>1</TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD><STRONG>October</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR>
<TD>10/23/07</TD>
<TD>Hotel Washington</TD>
<TD>289</TD>
<TD>01/01/08</TD>
<TD>1</TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD>10/29/07</TD>
<TD>Washington Gas</TD>
<TD>2</TD>
<TD>01/18/08</TD>
<TD>1</TD></TR>
<TR>
<TD><STRONG>September</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD>09/19/07</TD>
<TD>Washington Gas</TD>
<TD>2</TD>
<TD>10/31/07</TD>
<TD>1</TD></TR>
<TR>
<TD>09/24/07</TD>
<TD>Washington Gas</TD>
<TD>17</TD>
<TD>10/31/07</TD>
<TD>1</TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD>09/29/07</TD>
<TD>Aramark Sports, LCC</TD>
<TD>372</TD>
<TD>12/31/07</TD>
<TD>1</TD></TR>
<TR>
<TD><STRONG>July</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD>07/09/07</TD>
<TD>The Palms Restaurant</TD>
<TD>60</TD>
<TD>07/31/07</TD>
<TD>1</TD></TR>
<TR>
<TD>07/16/07</TD>
<TD>DC Department of Human Resources</TD>
<TD>12</TD>
<TD>08/31/07</TD>
<TD>1</TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD>07/23/07</TD>
<TD>Bureau of Rehabilitation</TD>
<TD>35</TD>
<TD>10/31/07</TD>
<TD>1</TD></TR>
<TR>
<TD>07/30/07</TD>
<TD>BAE Systems</TD>
<TD>140</TD>
<TD>09/30/07</TD>
<TD>1</TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD><STRONG>June</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR>
<TD>06/06/07</TD>
<TD>Prudential Financial -- Equity Group</TD>
<TD>9</TD>
<TD>08/14/07</TD>
<TD>2</TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD>06/27/07</TD>
<TD>Marriott Hotel Services, Inc.</TD>
<TD>108</TD>
<TD>08/31/07</TD>
<TD>1</TD></TR>
<TR>
<TD>06/27/07</TD>
<TD>Lockheed Martin</TD>
<TD>50</TD>
<TD>08/31/07</TD>
<TD>1</TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD><STRONG>May</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR>
<TD>05/25/07</TD>
<TD>The Republican National Committee - Phone Bank</TD>
<TD>71</TD>
<TD>07/24/07</TD>
<TD>1</TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD>05/30/07</TD>
<TD>Hecht's</TD>
<TD>20</TD>
<TD>08/14/07</TD>
<TD>2**</TD></TR>
<TR>
<TD>05/30/07</TD>
<TD>The Watergate Hotel</TD>
<TD>180</TD>
<TD>08/01/07</TD>
<TD>2</TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD><STRONG>March</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR>
<TD>03/08/07</TD>
<TD>Beverly Health &amp; Rehabilitation Services, Inc.</TD>
<TD>344</TD>
<TD>05/01/07</TD>
<TD>2</TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD><STRONG>February</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD>1</TD></TR>
<TR>
<TD>02/02/07</TD>
<TD>Hecht's</TD>
<TD>90</TD>
<TD>05/18/07</TD>
<TD>2</TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD>02/23/07</TD>
<TD>Bolling Air Force Base--USAF Real Property Agency</TD>
<TD>30</TD>
<TD>07/31/08</TD>
<TD>2 BRAC</TD></TR>
<TR>
<TD><STRONG>January</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD>01/03/06</TD>
<TD>FAA</TD>
<TD>10</TD>
<TD>02/28/06</TD>
<TD>1</TD></TR>
<TR>
<TD><STRONG>March</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD>03/09/06</TD>
<TD>Carey International</TD>
<TD>54</TD>
<TD>05/30/06</TD>
<TD>2</TD></TR>
<TR>
<TD>03/29/06</TD>
<TD>Hecht's</TD>
<TD>86</TD>
<TD>05/30/06</TD>
<TD>2</TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD>03/31/06</TD>
<TD>American Airlines</TD>
<TD>44</TD>
<TD>05/29/06</TD>
<TD>1</TD></TR>
<TR>
<TD><STRONG>May</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD>05/09/06</TD>
<TD>ARAMARK</TD>
<TD>149</TD>
<TD>07/24/06</TD>
<TD>2</TD></TR>
<TR>
<TD>05/31/06</TD>
<TD>Wakenhut Services, Inc.</TD>
<TD>90</TD>
<TD>07/31/06</TD>
<TD>1</TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD><STRONG>June</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR>
<TD>06/24/06</TD>
<TD>Carr America International</TD>
<TD>104</TD>
<TD>08/31/06</TD>
<TD>2</TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD>06/26/06</TD>
<TD>St. Regis Hotel</TD>
<TD>199</TD>
<TD>08/31/06</TD>
<TD>2</TD></TR>
<TR>
<TD><STRONG>July</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD>07/12/06</TD>
<TD>ABS LINCS/First Home Care</TD>
<TD>50</TD>
<TD>09/30/06</TD>
<TD>2</TD></TR>
<TR>
<TD><STRONG>August</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD>08/15/06</TD>
<TD>The Wall Street Journal</TD>
<TD>63</TD>
<TD>09/30/06</TD>
<TD>1</TD></TR>
<TR>
<TD>08/17/06</TD>
<TD>United Airlines</TD>
<TD>504</TD>
<TD>10/16/06</TD>
<TD>1</TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD><STRONG>October</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR>
<TD>10/03/06</TD>
<TD>Walter Reed Army Medical Center (BRAC/A76)</TD>
<TD>200</TD>
<TD>02/04/07</TD>
<TD>2</TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD><STRONG>November</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR>
<TD>11/07/06</TD>
<TD>US House of Representatives</TD>
<TD>200</TD>
<TD>01/02/07</TD>
<TD>1</TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD>11/07/06</TD>
<TD>US Senate</TD>
<TD>200</TD>
<TD>01/02/07</TD>
<TD>1</TD></TR>
<TR>
<TD><STRONG>December</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD>12/19/06</TD>
<TD>Hechts*</TD>
<TD>10</TD>
<TD>03/14/07</TD>
<TD>2</TD></TR>
<TR>
<TD>12/19/06</TD>
<TD>The Jefferson Hotel</TD>
<TD>100</TD>
<TD>03/01/07</TD>
<TD>2</TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD><STRONG>2005</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR>
<TD><STRONG>January</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR class=text bgColor=#e1ecf2>
<TR class=text bgColor=#e1ecf2>
<TD>01/27/05</TD>
<TD>FDIC Session II of IV</TD>
<TD>300</TD>
<TD>05/14/05</TD>
<TD>1</TD></TR>
<TR>
<TD>01/27/05</TD>
<TD>CareFirst Blue Cross Blue Shield</TD>
<TD>134</TD>
<TD>05/14/05</TD>
<TD>1</TD></TR>
<TR class=text bgColor=#e1ecf2>
<TR class=text bgColor=#e1ecf2>
<TD>01/27/05</TD>
<TD>FDIC Session I of IV</TD>
<TD>300</TD>
<TD>05/14/05</TD>
<TD>1</TD></TR>
<TR>
<TD>01/11/05</TD>
<TD>Department of Employment Services</TD>
<TD>34</TD>
<TD>02/11/05</TD>
<TD>1</TD></TR>
<TR>
<TR>
<TR class=text bgColor=#e1ecf2>
<TD><STRONG>March</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR class=text bgColor=#e1ecf2>
<TR>
<TD>03/28/05</TD>
<TD>Loew's L'Enfant Plaza Hotel</TD>
<TD>198</TD>
<TD>05/31/05</TD>
<TD>1</TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD>03/25/05</TD>
<TD>The Jefferson Hotel</TD>
<TD>98</TD>
<TD>05/25/05</TD>
<TD>1</TD></TR>
<TR>
<TD>03/23/05</TD>
<TD>Lockheed Martin</TD>
<TD>34</TD>
<TD>05/15/05</TD>
<TD>1</TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD>03/15/05</TD>
<TD>Cornell (JOS-ARZ Therapeutic)</TD>
<TD>50</TD>
<TD>05/13/05</TD>
<TD>1</TD></TR>
<TR>
<TR>
<TD>03/14/05</TD>
<TD>PNC Bank</TD>
<TD>164</TD>
<TD>05/15/05-06/24/05</TD>
<TD>1</TD></TR>
<TR>
<TR class=text bgColor=#e1ecf2>
<TD>03/8/05</TD>
<TD>Carey International, Inc.</TD>
<TD>63</TD>
<TD>06/3/05</TD>
<TD>1</TD></TR>
<TR>
<TD><STRONG>April</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD>04/13/05</TD>
<TD>Internal Revenue Service</TD>
<TD>6</TD>
<TD>11/30/05</TD>
<TD>1</TD></TR>
<TR>
<TD><STRONG>May</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD>05/5/05</TD>
<TD>Sterling Cleaners &amp; Textile Services</TD>
<TD>82</TD>
<TD>07/2/05</TD>
<TD>1</TD></TR>
<TR>
<TD>05/15/05</TD>
<TD>FAA</TD>
<TD>2</TD>
<TD>10/01/05</TD>
<TD>1</TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD>05/25/05</TD>
<TD>Park Hyatt Hotel</TD>
<TD>60</TD>
<TD>07/31/05</TD>
<TD>1</TD></TR>
<TR>
<TD>05/28/05</TD>
<TD>DC Public Schools Transportation</TD>
<TD>75</TD>
<TD>06/12/05</TD>
<TD>1</TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD><STRONG>June</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR>
<TD>06/01/05</TD>
<TD>FDIC</TD>
<TD>12</TD>
<TD>09/30/05</TD>
<TD>1</TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD>06/01/05</TD>
<TD>CACI--Justice Department</TD>
<TD>110</TD>
<TD>06/01/05-09/30/05</TD>
<TD>1</TD></TR>
<TR>
<TD><STRONG>July</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD>07/15/05</TD>
<TD>Greater SE Community Hospital</TD>
<TD>147</TD>
<TD>06/30/05</TD>
<TD>1</TD></TR>
<TR>
<TD>07/15/05</TD>
<TD>Greater SE Community Hospital</TD>
<TD>6</TD>
<TD>06/30/05</TD>
<TD>1</TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD><STRONG>September</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR>
<TD>09/27/05</TD>
<TD>East Capital Center for Change</TD>
<TD>14</TD>
<TD>09/30/05</TD>
<TD>1</TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD><STRONG>November</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR>
<TD>11/21/05</TD>
<TD>Library of Congress</TD>
<TD>31</TD>
<TD>09/30/06</TD>
<TD>2</TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD><STRONG>December</STRONG></TD>
<TD></TD>
<TD></TD>
<TD></TD>
<TD></TD></TR>
<TR>
<TD>12/08/05</TD>
<TD>Howard University Hospital</TD>
<TD>125</TD>
<TD>10/14/05</TD>
<TD>1</TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD>12/19/05</TD>
<TD>Holiday Inn Hotel</TD>
<TD>69</TD>
<TD>02/18/06</TD>
<TD>2</TD></TR>
<TR>
<TD>12/19/05</TD>
<TD>Downtown Holiday Inn</TD>
<TD>69</TD>
<TD>02/18/06</TD>
<TD>2</TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD>12/20/05</TD>
<TD>Library of Congress</TD>
<TD>20</TD>
<TD>02/28/06</TD>
<TD>1</TD></TR></TBODY></TABLE></DIV><SPAN>
<P style="MARGIN: 0in 0in 0pt"><SPAN><FONT face="" Times New Roman??><FONT size=3><FONT face="Times New Roman"><SPAN><FONT face="" size=3 Times New Roman??><SPAN>&nbsp;&nbsp; </SPAN></FONT></SPAN></FONT></FONT></FONT></SPAN></SPAN></P>
<DIV><FONT size=1><STRONG>*Code Type:&nbsp; </STRONG>1=Mass Layoff&nbsp;&nbsp; 2=Closure<BR>*Indicates more than one session-and to combine total of<BR></FONT></DIV></DSFCONTENTBODY>
</font>
<BR>
</DSFCONTENT><DSFRIGHTNAV>
<!--stopindex-->
</td>
				<td></td>
			  </tr>
			</table>
			<!--content ends here-->
		  </td>
		  <!--RIGHT NAV-->
		</tr>
	  </table>
<!--startindex-->
</DSFRIGHTNAV>

<DSFFOOTER>
<!--stopindex-->			
		<!-- footer -->
<DIV align=center>&nbsp; 
<STYLE>
.footer a {FONT-SIZE: 10px; FONT-FAMILY: Arial, Verdana, Geneva; TEXT-DECORATION: none;}
.footer a:hover {TEXT-DECORATION:underline;}
</STYLE>

<TABLE class=footer cellSpacing=0 cellPadding=0 width="100%">
<TBODY>
<TR vAlign=top><!-- White Line -->
<TD bgColor=#ffffff height=1><IMG alt="" src="../assets/templates/30/images/dot.gif"></TD></TR>
<TR vAlign=top><!-- Blue Line -->
<TD bgColor=#0d457f height=1><IMG alt="" src="../assets/templates/30/images/dot.gif"></TD></TR>
<TR vAlign=top><!-- Bottom Navigation -->
<TD align=middle bgColor=#ffffff><FONT id=smnormal><A class=dblue title="Telephone Directory by Topic" href="http://app.dc.gov/agencies/agency_search.asp">Telephone Directory by Topic</A> <IMG alt="" src="../assets/templates/30/images/greybullet.jpg"> <A class=dblue title=Agencies href="http://app.dc.gov/agencies/index.asp">Agencies</A> <IMG alt="" src="../assets/templates/30/images/greybullet.jpg"> <A class=dblue title="DC Council" href="http://www.dccouncil.washington.dc.us/" target=_blank>DC Council</A> <IMG alt="" src="../assets/templates/30/images/greybullet.jpg"> <A class=dblue title=Search href="http://google.dc.gov">Search</A> <IMG alt="" src="../assets/templates/30/images/greybullet.jpg"> <A class=dblue title="Elected Officials" href="http://dc.gov/DC/Government/Elected+Officials+&amp;+Elections">Elected Officials</A> <IMG alt="" src="../assets/templates/30/images/greybullet.jpg"> <A class=dblue title=Feedback href="http://feedback.dc.gov/">Feedback</A> <IMG alt="" src="../assets/templates/30/images/greybullet.jpg"> <A class=dblue title=Accessibility href="http://dc.gov/DC/About+DC.Gov/Accessibility">Accessibility</A> <IMG alt="" src="../assets/templates/30/images/greybullet.jpg"> <A class=dblue title="Privacy &amp; Security" href="http://dc.gov/DC/About+DC.Gov/Privacy+and+Security">Privacy &amp; Security</A> <IMG alt="" src="../assets/templates/30/images/greybullet.jpg"> <A class=dblue title="Terms &amp; Conditions" href="http://dc.gov/DC/About+DC.Gov/Terms+and+Conditions">Terms &amp; Conditions</A> </FONT></TD></TR></TBODY></TABLE></DIV>
<br>

<!-Google Analytics code start -->

<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-2638726-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>

<!-Google Analytics code end -->

<!--startindex--><meta NAME="Title" Content="DOES: Monthly WARN Notification Log"><meta NAME="DocTitle" Content="DOES: Monthly WARN Notification Log"><meta NAME="Description" Content="Monthly WARN Notification Log  Abstract: Rapid Response Event Log        Notice  DateAgency/OrganizationNumber of  Employees  AffectedEffective  Layoff DateType*  CodeJanuary01/11/12DC Department of Health182November11/21/11Filene's Basement/Syms Clothing2012October10/12/11Tourmobile Sightseeing1122September09/28/11Defenders of Wildlife14109/21/11DC Child and Family Services Agency8109/21/11DC Metropolitan Police Department15109/13/11WSI45109/07/11DC Office of Contracting and Procurement40109/07/11DC Department of Public Works511AugustScience Applications International Corporation801Tourmobile Sightseeing1122Lockheed Martin Electronic Systems Global Training and Logistic51U.S. Dept. of the Interior Bureau of Ocean Energy Management151July07/05/11Capitol City Brewing Company902June06/22/11A&amp;P (Super Fresh)571RTS (Verizon Wireless)111May05/04/11Walter Reed Army Medical Center1501March3/25&amp;29/2011Howrey, LLP4272January01/04/11U.S. Department of Energy/ BP Oil Commission301December12/06/10U.S.House of Representatives400112/06/10U.S. Senate2501September09/24/10Computer Sciences Corporation47109/21/10US Department of Energy51July07/19/10Wackenhut Services Incorporated731June06/16/10ESPN Sport Zone1522May05/14/10VMT Long Term Care Management, Inc4002April04/13/10Central Parking1491January01/15/10Allied Capital911DecemberN/AAllied Capital91112/09/09Washington Times40012/09-10/091October10/30/09Citi Bank111September09/30/09Office of the Attorney General10109/30/09Ombudsman for Public Education1109/24/09Office of Tenant Advocate6109/24/09Department of Motor Vehicles6109/23/09DC Sports and Entertainment Commission20209/03/09DC Department of Health Care Finance80109/03/09DC National Guard1109/02/09DC Office of Chief Medical Examiner31August08/25/09DC Public Schools Office of  Facilities Modernization50108/07/09DC Department of Parks and Recreation100108/07/09DC Homeland Security and Emergency Management2108/07/09DC Department of Consumer and Regulatory Affairs2108/07/09DC Department of Motor Vehicles1108/07/09DC Office of Planning5108/07/09DC Department of Health 801July07/23/09DC Department of Transportation6507/31/09107/22/09Southeastern University2007/31/09107/07/09DC Department of Mental Health12007/31/091June06/10/09Balducci's Food Market8606/30/09206/10/09Office of Partnership and Grant Services1106/10/09Department on Disability Services5106/10/09DC Department of Human Services 1May05/13/09Child and Family Services Agency1April04/30/09Department of Parks and Recreation18104/23/09Office of Labor Relations and Collective Bargaining1104/23/09Office of Public Education Facilities Modernization2104/23/09Department of Motor Vehicles4104/23/09Office of Risk Management3104/23/09Office of Contracting and Procurement6104/23/09Office on Human Rights1104/23/09The Taxicab Commission1104/23/09DCTV/Office of Cable Television5104/01/09Fried Frank, LLP201February02/03/09Gannet News Services571January01/22/09DC Office of the Attorney General31December12/2008US General Services Administration7512/18/08112/2008US Department of the Interior5012/17/08112/2008US Department of Labor5012/12/081November11/17/08Fried Frank, LLP1511/20/081October10/24/08US Department of Transportation11011/19/08110/24/08US Department of Housing &amp; Urban Development11011/13/08110/23/08Gate Gourmet, Inc.122110/22/08US Department of Commerce15011/21/08110/17/08US Department of Energy5011/14/08110/2008Executive Office of the President50012/3/08110/2008US Department of Education7012/5/08110/3/08Revolution Health Group471September9/26/08Heller Ehrman, LLP9829/2008US Department of Agriculture10512/3/0819/2008US House of Representatives45612/4/081August08/21/08Jurys Washington Hotel1759/11/2008108/05/08The Washington Times7008/15/19/28/08108/06/08DC Department of Health2508/27/08108/06/08DC Dept. of Youth Rehabilitation Services2508/27/081March 03/06/08American Institute for Cancer Research 4N/A103/14/08American Red Cross National Headquarters 40804/25/28/30 and 05/02/08103/16/08Bureau of Rehabilitation 2003/18/082January 01/31/08DC Department of Human Resources802/07/08101/31/08Washington Gas102/13/081December12/10/07MVM,  Inc.511/31/082November11/14/07Dewey &amp; LeBeouf, LPP2001/11/08 &amp; 01/31/08111/14/07Resources for Human Development, Inc.201/31/08211/14/07Capitol Health Management Services, LCC2511/30/07111/19/07Washington Gas21/18/20081October10/23/07Hotel Washington28901/01/08110/29/07Washington Gas201/18/081September09/19/07Washington Gas210/31/07109/24/07Washington Gas1710/31/07109/29/07Aramark Sports, LCC37212/31/071July07/09/07The Palms Restaurant6007/31/07107/16/07DC Department of Human Resources1208/31/07107/23/07Bureau of Rehabilitation3510/31/07107/30/07BAE Systems14009/30/071June06/06/07Prudential Financial -- Equity Group908/14/07206/27/07Marriott Hotel Services, Inc.10808/31/07106/27/07Lockheed Martin5008/31/071May05/25/07The Republican National Committee ..."><meta NAME="Date" Content="2012-1-31">
	
	<!-- DSF: PROPER END OF PAGE -->
		


	</DSFFOOTER>
	</body>
</html>
