
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML LANG="en-us">
	<DSFHEADER>
	<!--stopindex-->
	<HEAD>
		<!-- 
			This site was built with PPT DSF Technology
		Dynamic Site Framework	(c) 1999-2005 PPT, Lancaster PA
		-->

		<meta http-equiv="content-type" content="text/html;charset=iso-8859-1">
		
		
		
		
		<meta NAME="rating" CONTENT="general">
		<meta name="IS" content="ok_trust">
		<meta NAME="distribution" CONTENT="global">
		<meta NAME="MS.LOCALE" LANG="en-us" CONTENT="EN-US">
		<meta NAME="generator" Content="OIT-DSF: PPT v2.1">
		<meta NAME="copyright" CONTENT="Enter your Company or Top-Level Office.">
		<meta NAME="alias" CONTENT="http://does.dc.gov/does/">
		<meta NAME="author" CONTENT="Enter your Company or Top-Level Office">
		<meta NAME="owner" Content="Content: Contact System Admin / Enter your Company or Top-Level Office">
		<meta NAME="robots" CONTENT="all">
		<meta NAME="revisit-after" CONTENT="15 days">
		<meta HTTP-EQUIV="reply-To" CONTENT="mainteditor@dc.gov">
		
		
		<title>Department of Employment Services: Monthly WARN Notification Log</title>
			
		 
<style type='text/css'>
.hidden	{ display:none; }
</style>

<style type="text/css">
		BODY { 
			
			font-family: 'Arial,Helvetica,Geneva';
			font-size: 'x-small';
						BACKGROUND-COLOR: ##FFFFFF
			}
		
		A:LINK { color:  }
		
		A:VISITED { color:  }
		
		A:HOVER { color:  }
		
		A:ACTIVE { color:  }
		
		.pagecolor	{ background-color: ##FFFFFF }
		A.pageopposite { color: #ffffff }
		.schemecolor1 { background-color: ##6483C5 }
		.schemecolor2 { background-color: ##001864 }
		.textcolor1 { color: ##6483C5 }
		.textcolor2 { color: ##001864 }
		
		TD { 
			font-family: 'Arial,Helvetica,Geneva';
			font-size: 'x-small';
		}
.Page-Title
{
	COLOR: #001864;
	FONT-SIZE: 13.5pt;
	FONT-FAMILY: Arial;
	TEXT-DECORATION: none;
	font-weight: bold;
}

.content
{
    COLOR: #000000;
    FONT-SIZE: 10pt;
    FONT-FAMILY: Arial;
    TEXT-DECORATION: none
}

.nounder {FONT-FAMILY: arial, verdana, helvetica, sans-serif; TEXT-DECORATION: none}

.white {COLOR: #ffffff; TEXT-DECORATION: none;}

A.white:hover {COLOR: #ffffcc; TEXT-DECORATION: underline;}

.lblue {COLOR: #eaf4ff; TEXT-DECORATION: none}

A.lblue:hover {COLOR: #ffffcc; TEXT-DECORATION: underline}

.red {COLOR: #ff0000; TEXT-DECORATION: none}

.red1 {COLOR: #ff0000; TEXT-DECORATION: none}

A.red1:hover {COLOR: #001864; TEXT-DECORATION: none}

.blue  {COLOR: #001864; TEXT-DECORATION: none}

A.visited.blue  {COLOR: #001864; TEXT-DECORATION: none}

A:active.blue  {COLOR: #001864; TEXT-DECORATION: none}

A.blue:link  {COLOR: #001864; TEXT-DECORATION: none}

A.blue:hover {COLOR: #ff0000; TEXT-DECORATION: none}

.ured {COLOR: #ff0000; TEXT-DECORATION: underline;}

A.ured:hover {COLOR: #001864; TEXT-DECORATION: underline;}

.black {COLOR: #000000; TEXT-DECORATION: none;}

A.visited.black {COLOR: #000000; TEXT-DECORATION: none;}

A:active.black {COLOR: #000000; TEXT-DECORATION: none;}

A.black:hover {COLOR: #ff0000; TEXT-DECORATION: underline;}

.highlight {BACKGROUND-COLOR: #eaeaea;}

.ltblue {color: #9DAEE8; text-decoration: none;}

A.ltblue:hover {COLOR: #ffffcc; TEXT-DECORATION: underline;}

.searchBox {background-color: #B5C1E7; border-color: #B5C1E7 #B5C1E7 #001E7A; border-style: solid; border-bottom-width: 1px}

.navLink {color: #001F7C; text-decoration: none ; font-family: Arial, Verdana, Geneva; font-size: 11px; font-weight: bold}

A.navLink:hover {color: #CC0000; text-decoration: underline}

.widgetLinks {font-family: Verdana, Arial, Geneva; font-size: 10px; text-decoration: none}

A.widgetLinks:hover { color: #001E7A; text-decoration: underline}

.agencyTitle {
	color: #001864;
	font-family: Verdana;
	font-size: 18pt;
	font-weight: bold;
	line-height: 20pt;
}

A.white:visited {color: #FFFFFF;text-decoration: none;}

A.white:active {color: #FFFFFF;text-decoration: none;}

A.red:visited {COLOR: #FF0000; TEXT-DECORATION: none}

A.red:active {COLOR: #FF0000; TEXT-DECORATION: none}

A.red:link {COLOR: #FF0000; TEXT-DECORATION: none}

A.red:hover {COLOR: #001864; TEXT-DECORATION: underline}

.table-categories{font-family: arial;font-size: 10pt;color: #FFFFFF;font-weight: bold;background-color: #83A0C8;}

.table-row1 {font-family: arial;font-size: 10pt;color: #000000;background-color: #FFFFFF;}

.table-row2 {font-family: arial;font-size: 10pt;color: #000000;background-color: #E1ECF2;}

A:link {text-decoration: none;}

A:visited {text-decoration:none;}

A:hover {COLOR:#000000; TEXT-DECORATION: underline;}

A:active {text-decoration:none;}

A:unknown {COLOR: #ffffcc; TEXT-DECORATION: underline;}

.navtax {font-family: Arial, Geneva; font-size: 10px; color: #FFFFFF; text-decoration: none}

.navtax:hover {font-family: Arial, Geneva; font-size: 10px; color: #FFFFCC; text-decoration: underline}

.taxsubnav {font-family: Verdana, Arial, Geneva; font-size: 9px; color: #eaf4ff; text-decoration: none}
   
.taxsubnav:hover {font-family: Arial, Geneva; font-size: 9px; color: #FFFFCC; text-decoration: underline}


</style>
</head>
<a href="#navskip"><img class=hidden src=../assets/images/spacer.gif height=0 border=0 alt='Skip to main content'></a>
	
<a name='top'>
<BODY text="#000000" vLink="#000080" link="#1e90ff" bgColor="#ffffff" leftMargin="0" topMargin="0" MARGINWIDTH="0" MARGINHEIGHT="0">
<LINK href="../assets/templates/30/inc/main2.css" rel="stylesheet" type="text/css">
	<DIV id=tooltip onmouseover=clearTimeout(TimerID) style="Z-INDEX: 10; VISIBILITY: hidden; POSITION: absolute" onmouseout=showMenu(0)></DIV>
<TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
<SCRIPT language=javascript id=wl_base>
  var wl_url = ""; // The standard WorldLingo translation link (justappend
//the escaped FULL destination url)
  var wl_burl = ""; // The standard WorldLingo translation link with
//baseHref included
  var wl_ourl = ""; // The original page that has been translated
  var wl_rurl = ""; // The previous page that the user viewed
  var wl_srclang = ""; // The source lang (ie EN) for this translation
  var wl_srclanguage = ""; // The source language (ie English) for this
//translation
  var wl_trglang = ""; // The target lang (ie EN) for this translation
  var wl_trglanguage = ""; // The target language (ie English) for this
//translation
</SCRIPT>

<SCRIPT language=JavaScript src="/vincludes/global.asp" wl_replace="attrib=src,IT=/vincludes/global_it.asp,ES=/vincludes/global_es.a&#13;&#10;sp,EN=/vincludes/global.asp,FR=/vincludes/global_fr.asp,PT=/vincludes/global&#13;&#10;_br.asp,DE=/vincludes/global_de.asp,NL=/vincludes/global_nl.asp,EL=/vinclude&#13;&#10;s/global_gre.asp"></SCRIPT>

<TBODY>
<TR>
<TD width=112><A id=test0 href="http://dc.gov/index.asp" name=test0><IMG onmouseover="showMenu(1, 'drop0', getAnchorX('test0'), 18)" onmouseout=showMenu(0) height=18 alt="DC Home" src="../assets/templates/19/images/nav_home.gif" width=112 border=0></A></TD>
<TD width=102><A id=test1 href="http://about.dc.gov/index.asp" name=test1><IMG onmouseover="showMenu(1, 'drop1', getAnchorX('test1'), 18)" onmouseout=showMenu(0) height=18 alt="DC Guide" src="../assets/templates/30/images/nav_about.gif" width=102 border=0></A></TD>
<TD width=112><A id=test2 href="http://www.rrc.dc.gov/rrc/site/default.asp" name=test2><IMG onmouseover="showMenu(1, 'drop2', getAnchorX('test2'), 18)" onmouseout=showMenu(0) height=18 alt=Residents src="../assets/templates/30/images/nav_residents.gif" width=112 border=0></A></TD>
<TD width=112><A id=test3 href="http://brc.dc.gov/index.asp" name=test3><IMG onmouseover="showMenu(1, 'drop3', getAnchorX('test3'), 18)" onmouseout=showMenu(0) height=18 alt=Business src="../assets/templates/30/images/nav_business.gif" width=112 border=0></A></TD>
<TD width=112><A id=test4 href="http://www.vrc.dc.gov/vrc/site/default.asp" name=test4><IMG onmouseover="showMenu(1, 'drop4', getAnchorX('test4'), 18)" onmouseout=showMenu(0) height=18 alt=Visitors src="../assets/templates/30/images/nav_visitors.gif" width=112 border=0></A></TD>
<TD width=112><A id=test5 href="http://www.grc.dc.gov/grc/site/default.asp" name=test5><IMG onmouseover="showMenu(1, 'drop5', getAnchorX('test5'), 18)" onmouseout=showMenu(0) height=18 alt="DC Government" src="../assets/templates/30/images/nav_dcgov.gif" width=112 border=0></A></TD>
<TD width=108><A href="http://kids.dc.gov"><IMG height=18 alt=Kids src="../assets/templates/30/images/nav_kids.gif" width=108 border=0></A></TD>
<TD width="100%" background=../assets/templates/30/images/nav_spacer.gif><IMG height=1 alt="" src="../assets/templates/30/images/dot.gif" width=1></TD></TR>
<TR>
<TD vAlign=top align=right width="100%" background=../assets/templates/30/img/header_test_bg.jpg colSpan=8><IMG height=75 alt="Welcome to Washington District of Columbia" src="../assets/templates/30/img/header_flag_title3.gif" width=310 align=left><A href="http://dc.gov/mayor/index.shtm"><IMG height=73 alt="Mayor Anthony Williams" src="../assets/templates/30/images/header_mayor_head.gif" width=287 border=0></A></TD></TR><!--<TR>
<TD bgColor=#cc3333 colSpan=2></TD></TR>--></TBODY></TABLE>
		<TABLE cellSpacing=0 cellPadding=0 width=600 border=0>
		<TBODY>
			<TR>
				<TD vAlign=top align=left width=10 bgColor=#3253bb><IMG height=1 alt=" " src="../Assets/templates/30/img2/dot.gif" width=10 border=0><BR></TD><!-- Modify Template Page Name Here -->
				<TD vAlign=center align=left width=550 bgColor=#3253bb ?nowrap?><FONT face=Arial color=#ffffff size=4><B>Department of Employment Services</B></FONT><BR></TD>
				<TD vAlign=top align=left width=240 background=../Assets/templates/30/img2/grad_bar1.gif bgColor=#ffffff><IMG height=25 alt=" " src="../Assets/templates/30/img2/grad_bar.gif" width=67 border=0><BR></TD></TR></TBODY></TABLE>
	
<!--startindex-->
</DSFHEADER>

<DSFNAV><!--stopindex-->


<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
	<!-- LEFT NAV start-->
  <td valign="top" width="124" bgcolor="#001864">
	<table border="0" cellspacing="0" cellpadding="0" width="124">
	  <tr>
		<td width="5"><img src="../assets/templates/30/images/spacer.gif" width="5" height="10" alt=""></td>
		<td valign="top" width="119"><img src="../assets/templates/30/images/dot.gif" width="1" height="1" alt=""></td>
	  </tr>
		
	  <tr>
		<td><img src="../assets/templates/30/images/dot.gif" width="1" height="1" alt=""></td>
		<td valign="top">
		
		  <!-- TAXONOMY STARTS HERE -->
		  
		  <table border="0" cellspacing="0" cellpadding="0" width="120">
			<tr>
			  <td valign="top" height="2"></td>
			  <td valign="top" width="120" height="2">
			

<SCRIPT language="javascript"> 
function SwapImg_doesNav(ImgID_str, Url_str, fheight_int, fwidth_int){
		document.images[ImgID_str].src = Url_str;
		document.images[ImgID_str].height = fheight_int;
		document.images[ImgID_str].width = fwidth_int;
		}
</SCRIPT>

<TABLE border="0" cellpadding="0" cellspacing="0" valign="top"><TR><TD valign="top" align="left" nowrap><a href="/does/cwp/view.asp?a=1232&q=572897&doesNav=|32060|"><IMG name="32060" src="/does/Assets/Templates/30/images/bul_dot.gif" height="1" width="1" border="0" alt="View sub-links" ></a></td><td valign="middle"><A name="32060" href="/does/site/default.asp?doesNav=|32060|"  class="navtax"><FONT FACE='verdana'><b>DOES HOME</b><br></font></A></Td></Tr><TR><TD valign="top" align="left" nowrap><IMG src="/does/Assets/Templates/30/images/bul_dot_sub.gif" height="1" width="1" border="0" alt='' ></td><td valign="middle">&nbsp;</Td></Tr><TR><TD valign="top" align="left" nowrap><a href="/does/cwp/view.asp?a=1232&q=572897&doesNav=|32062|"><IMG name="32062" src="/does/Assets/Templates/30/images/bul_dot.gif" height="1" width="1" border="0" alt="View sub-links" ></a></td><td valign="middle"><A name="32062" href="/does/cwp/view,a,1232,q,537715,doesNav,|32062|,.asp"  class="navtax"><FONT FACE='verdana'><b>SERVICES</b></font><br></A></Td></Tr><TR><TD valign="top" align="left" nowrap><IMG src="/does/Assets/Templates/30/images/bul_dot_sub.gif" height="1" width="1" border="0" alt='' ></td><td valign="middle">&nbsp;</Td></Tr><TR><TD valign="top" align="left" nowrap><a href="/does/cwp/view.asp?a=1232&q=572897&doesNav=|32064|"><IMG name="32064" src="/does/Assets/Templates/30/images/bul_dot.gif" height="1" width="1" border="0" alt="View sub-links" ></a></td><td valign="middle"><A name="32064" href="/does/cwp/view,a,1233,q,538338,doesNav,|32064|,.asp"  class="navtax"><FONT FACE='verdana'><b>INFORMATION</b></font></A></Td></Tr><TR><TD valign="top" align="left" nowrap><IMG src="/does/Assets/Templates/30/images/bul_dot_sub.gif" height="1" width="1" border="0" alt='' ></td><td valign="middle">&nbsp;</Td></Tr><TR><TD valign="top" align="left" nowrap><IMG src="/does/Assets/Templates/30/images/bul_dot_sub.gif" height="1" width="1" border="0" alt='' ></td><td valign="middle"><A name="32066" href="http://www.washingtondc.gov/contact/index.htm?doesNav=|"  class="navtax"><FONT FACE='verdana'><b>ONLINE SERVICE<br>��REQUESTS</b></font></A></Td></Tr></table>
			  </td>
			</tr>
		  </table>
		  
		  <!-- TAXONOMY ENDS HERE -->
		</td>
	  </tr>
	  <!-- Login starts here -->
	  <tr>
		<td height="15"><img src='../assets/templates/30/images/dot.gif' width='1' height='1' alt=''></td>
		<td><img src='../assets/templates/30/images/dot.gif' width='1' height='1' alt=''></td>
	  </tr>
	<!--  <tr>
		<td></td>
		<td>
		  <table border="0" cellspacing="0" cellpadding="0">
			<tr>
			  <td valign="top" width="12"><img src='../assets/templates/30/bullets/bul_dot_sub.gif' width='10' height='12' alt=''></td>
			  <td valign="top" nowrap></td>
			</tr>
		  </table>
		</td>
	  </tr>
	  <tr>
		<td></td>
		<td></td>
	  </tr>-->
	  <!-- login ends here -->
	  <!-- site admin link start-->
	  <tr> 
		<td height="10"><img src="../assets/templates/30/images/dot.gif" width="1" height="1" alt=""></td>
		<td><img src="../assets/templates/30/images/dot.gif" width="1" height="1" alt=""></td>
	  </tr>
	  <tr> 
		<td></td>
		<td>
		  <table border="0" cellspacing="0" cellpadding="0">
			<tr>
			  <td valign="top" width="12"><img src='../assets/templates/30/bullets/bul_dot_sub.gif' width='10' height='12' alt=''></td>
			  <td valign="top"><font face="Arial, Verdana, Geneva" size="1">
			  
			  </td>
			</tr>
			<tr> 
				<td height="10"><img src="../assets/templates/30/images/dot.gif" width="1" height="1" alt=""></td>
				<td><img src="../assets/templates/30/images/dot.gif" width="1" height="1" alt=""></td>
			</tr>
			<tr>
				<td></td>
				<td></td>
			</tr>
		  </table>
		</td>
	  </tr>
	  <tr>
		<td></td>
		<td></td>
	  </tr>
	  <!-- site admin link end -->
	  
	</table>
  </td>
  <!-- LEFT NAV END -->
	<td></td>
	<td valign="top">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td valign="top">
					<table border="0" cellspacing="0" cellpadding="10">
						<tr>
							<td width="100%">
								<!--content start-->
	<!--startindex-->
	</DSFNAV><a name="navskip"></a>
	<DSFCONTENT ID="6279" NAME="does" ABBREV="Department of Employment Services" TITLE="Department of Employment Services" CONTACT="mainteditor@dc.gov" uuid="18431982-D38C-4071-9654-384F98D0FFDB">
   <font face='Arial,Helvetica,Geneva' size='4' color=#001864><b><!-- <DSFAPP id=1232>Services</DSFAPP> -->
<!-- <DSFCONTENTCATEGORY id=44509 uuid="CBA16781-3CE3-4013-AF1A-1B02B1186286">Services</DSFCONTENTCATEGORY> --></b></font>
<P>
<!-- <DSFCONTENTTAGLINE id=572897></DSFCONTENTTAGLINE> --><FONT face='Arial,Helvetica,Geneva' size='2'>
<DSFCONTENTBODY id=572897 uuid="B0DD4276-A29F-409B-8ACB-F3185525C341"><P align=left><SPAN><FONT face="" size=3 Roman?? New Times><STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;DEPARTMENT OF EMPLOYMENT SERVICES<BR><SPAN><FONT size=3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; WORKFORCE DEVELOPMENT BUREAU</FONT></SPAN></STRONG></FONT></SPAN></P>
<DIV><STRONG>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Worker Adjustment and Retraining Notice (WARN) Log Year 2003</STRONG></DIV><STRONG>
<DIV><BR>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; MONTHLY WARN NOTIFICATION LOG<BR></DIV>
<DIV>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; CALENDAR YEAR 2003</DIV>
<DIV>&nbsp;</DIV>
<DIV>&nbsp;</DIV>
<DIV></STRONG>
<TABLE id=StdTable cellSpacing=1 cellPadding=2 width="100%" border=0>
<TBODY>
<TR class=header bgColor=#83a0c8>
<TD><FONT face=Arial color=#ffffff size=2><B contentEditable=true>
<DIV align=left><FONT face=Arial size=2>Notice<BR>Date</FONT></DIV></B></FONT></TD>
<TD><FONT face=Arial color=#ffffff size=2><B contentEditable=true>Company/Organization</B></FONT></TD>
<TD><FONT face=Arial color=#ffffff size=2><B contentEditable=true>
<DIV align=left><FONT face=Arial size=2>Number of<BR>Employees<BR>Affected</FONT></DIV></B></FONT></TD>
<TD><FONT face=Arial color=#ffffff size=2><B contentEditable=true>
<DIV align=left><FONT face=Arial size=2>Effective Date</FONT></DIV></B></FONT></TD>
<TD><FONT face=Arial color=#ffffff size=2><B contentEditable=true>
<DIV align=left><FONT face=Arial size=2>Type*<BR>Code</FONT></DIV></B></FONT></TD></TR>
<TR class=text>
<TD><FONT contentEditable=true face=Arial color=black size=2>
<DIV align=left>10/08/2003</DIV></FONT></TD>
<TD>
<DIV align=left>&nbsp;&nbsp; Omniplex<BR><STRONG>&nbsp;&nbsp; WARN</STRONG></DIV></TD>
<TD>&nbsp;&nbsp; 98</TD>
<TD>
<DIV align=left>01/08/2004</DIV></TD>
<TD>&nbsp;&nbsp; 1</TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD>
<DIV class=black align=left>10/03/2003</DIV></TD>
<TD>
<DIV>&nbsp;&nbsp;&nbsp; Team Video Services</DIV>
<DIV align=left>&nbsp;&nbsp;&nbsp; <STRONG>WARN</STRONG></DIV></TD>
<TD>&nbsp;&nbsp; 97</TD>
<TD>12/07/2003</TD>
<TD>&nbsp;&nbsp; 1</TD></TR>
<TR class=text>
<TD>05/30/2003</TD>
<TD>&nbsp;&nbsp;&nbsp; DigitalNet<BR><STRONG>&nbsp;&nbsp;&nbsp; WARN</STRONG></TD>
<TD>&nbsp;&nbsp;&nbsp;52&nbsp;&nbsp; </TD>
<TD>07/31/2003</TD>
<TD>&nbsp;&nbsp; 1</TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD>&nbsp;05/01/2003</TD>
<TD>&nbsp;&nbsp;&nbsp;Northrop Grumman&nbsp; 
<DIV align=left><STRONG>&nbsp;&nbsp; WARN</STRONG></DIV></TD>
<TD>
<DIV align=left>&nbsp;&nbsp;&nbsp;75<BR>&nbsp;&nbsp; </DIV></TD>
<TD>06/30/2003</TD>
<TD>&nbsp;&nbsp; 1</TD></TR>
<TR class=text>
<TD>&nbsp;03/17/2003</TD>
<TD>&nbsp;&nbsp; United Airlines 
<DIV align=left><STRONG>&nbsp;&nbsp; WARN</STRONG></DIV></TD>
<TD>&nbsp;&nbsp;&nbsp;94<BR>&nbsp;&nbsp; </TD>
<TD>04/01/2003</TD>
<TD>&nbsp;&nbsp; 1</TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD>&nbsp;01/08/2003</TD>
<TD>
<DIV>&nbsp;&nbsp;&nbsp;United Airlines&nbsp;</DIV>
<DIV align=left><STRONG>&nbsp;&nbsp; WARN</STRONG></DIV></TD>
<TD>&nbsp;&nbsp; 8<BR>&nbsp;&nbsp; ALPA<BR>&nbsp;&nbsp; Employees</TD>
<TD>03/02/2003</TD>
<TD>&nbsp;&nbsp; 1</TD></TR>
<TR class=text>
<TD>&nbsp;12/30/2002</TD>
<TD>
<DIV>&nbsp;&nbsp;&nbsp;United Airlines&nbsp; </DIV>
<DIV align=left><STRONG>&nbsp;&nbsp; WARN</STRONG></DIV></TD>
<TD>&nbsp;&nbsp; Unspecified<BR>&nbsp;&nbsp; Number</TD>
<TD>01/19/2003</TD>
<TD>&nbsp;&nbsp; 1</TD></TR>
<TR class=text bgColor=#e1ecf2>
<TD>&nbsp;12/12/2002</TD>
<TD>&nbsp;&nbsp;&nbsp;Getronics<BR>&nbsp;&nbsp; Government Solutions<BR>&nbsp;&nbsp; <STRONG>WARN</STRONG></TD>
<TD>&nbsp;&nbsp; 50</TD>
<TD>02/10/2003</TD>
<TD>&nbsp;&nbsp; 1</TD></TR>
<TR class=text>
<TD>&nbsp;11/01/2002</TD>
<TD>
<DIV>&nbsp;&nbsp;&nbsp;Kennedy Center's<BR>&nbsp;&nbsp; Hors d'Oeuvreie<BR>&nbsp;&nbsp; Restaurant&nbsp; </DIV>
<DIV align=left><STRONG>&nbsp;&nbsp; WARN</STRONG></DIV></TD>
<TD>&nbsp;&nbsp; 67</TD>
<TD>01/06/2003</TD>
<TD>&nbsp;&nbsp; 1</TD></TR></TBODY></TABLE></DIV><SPAN>
<P style="MARGIN: 0in 0in 0pt"><SPAN><FONT face="" Roman?? New Times><FONT size=3><FONT face="Times New Roman"><SPAN><FONT face="" size=3 Roman?? New Times><SPAN>&nbsp;&nbsp;<SPAN><FONT face="" Roman?? New Times><FONT size=3><FONT face="Times New Roman"><SPAN><FONT face="" size=3 Roman?? New Times><SPAN> </SPAN></FONT></SPAN></FONT></FONT></FONT></SPAN></SPAN></FONT></SPAN></FONT></FONT></FONT></SPAN></SPAN></P>
<DIV><FONT size=1><STRONG>*Type Code:&nbsp; </STRONG>1-Mass Layoff&nbsp;&nbsp; 2-Closure</FONT></DIV></DSFCONTENTBODY>
</font>
<BR>
</DSFCONTENT><DSFRIGHTNAV>
<!--stopindex-->
</td>
				<td></td>
			  </tr>
			</table>
			<!--content ends here-->
		  </td>
		  <!--RIGHT NAV-->
		</tr>
	  </table>
<!--startindex-->
</DSFRIGHTNAV>

<DSFFOOTER>
<!--stopindex-->			
		<!-- footer -->
<TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
<TBODY>
<TR>
<TD width=10><IMG height=1 alt=" " src="../assets/templates/13/img/dot.gif" width=10 border=0><BR></TD>
<TD>
<TABLE cellSpacing=0 cellPadding=0 width="100%" summary="graphical line" border=0>
<TBODY>
<TR>
<TD bgColor=#213c8b colSpan=5 height=3><IMG height=5 alt=- src="../assets/templates/13/img/dot.gif" width=1 border=0><BR></TD></TR></TBODY></TABLE><IMG height=1 alt=" " src="../assets/templates/13/img/dot.gif" width=1 border=0><BR>
<TABLE cellSpacing=0 cellPadding=0 width="100%" summary="footer navigation" border=0>
<TBODY>
<TR>
<TD vAlign=top width=250>
<TABLE cellSpacing=0 cellPadding=2 width="100%" summary="footer navigation - telephone numbers" border=0>
<TBODY>
<TR>
<TD><IMG height=1 alt=" " src="../assets/templates/13/img/dot.gif" width=195 border=0><BR><SPAN class=foot1>Government of the District of Columbia<BR>Citywide Call Center : (202) 727-1000<BR></SPAN><SPAN class=foot4><A class=foot4 href="http://dc.gov/tty.asp" target=_parent>TTY/TDD Directory</A></SPAN></TD></TR></TBODY></TABLE></TD>
<TD width=1 bgColor=#cccccc><IMG height=1 alt=" " src="../assets/templates/13/img/dot.gif" width=1 border=0><BR></TD>
<TD width="100%" bgColor=white>
<TABLE cellSpacing=0 cellPadding=0 width="100%" summary="footer navigation - links" border=0>
<TBODY>
<TR>
<TD width=10><IMG height=1 alt=" " src="../assets/templates/13/img/dot.gif" width=1 border=0><BR></TD>
<TD class=foot4 align=middle><A class=foot4 title="telephone directory by topic" href="http://dc.gov/agencies/agency_search.asp" target=_parent>Telephone Directory by Topic</A> <IMG height=1 alt=" " src="../assets/templates/13/img/dot.gif" width=5 border=0>|<IMG height=1 alt=" " src="../assets/templates/13/img/dot.gif" width=5 border=0> <A class=foot4 href="http://dc.gov/agencies/index.asp" target=_parent>Agencies</A> <IMG height=1 alt=" " src="../assets/templates/13/img/dot.gif" width=5 border=0>|<IMG height=1 alt=" " src="../assets/templates/13/img/dot.gif" width=5 border=0> <A class=foot4 href="http://grc.dc.gov/grc/cwp/view.asp?a=1206&amp;q=447541" target=_parent>DC Council</A> <IMG height=1 alt="" src="../assets/templates/13/img/dot.gif" width=5 border=0>|<IMG height=1 alt="" src="../assets/templates/13/img/dot.gif" width=5 border=0> <A class=foot4 href="http://dc.gov/jeevesone/query.asp" target=_parent>Search</A> <IMG height=1 alt="" src="../assets/templates/13/img/dot.gif" width=5 border=0>|<IMG height=1 alt="" src="../assets/templates/13/img/dot.gif" width=5 border=0> <A class=foot4 href="http://grc.dc.gov/grc/cwp/view,a,1203,Q,447121,grcNav_GID,1424.asp" target=_parent>Elected Officials</A><BR><IMG height=3 alt=" " src="../assets/templates/13/img/dot.gif" width=1 border=0><BR></TD></TR>
<TR>
<TD bgColor=#cccccc colSpan=2 height=1><IMG height=1 alt=" " src="../assets/templates/13/img/dot.gif" width=1 border=0><BR></TD></TR>
<TR>
<TD width=10>
<SCRIPT>
function doTranslate() {
var thislink = document.location.href;
window.location.href = "http://dc.gov/translations.asp?page="+escape(thislink);
}
</SCRIPT>
<IMG height=1 alt=" " src="../assets/templates/13/img/dot.gif" width=1 border=0><BR></TD>
<TD class=foot4 align=middle><A class=foot4 href="http://dc.gov/contact/index.shtm" target=_parent>Feedback</A> <IMG height=1 alt=" " src="../assets/templates/13/img/dot.gif" width=5 border=0>|<IMG height=1 alt="" src="../assets/templates/13/img/dot.gif" width=5 border=0>&nbsp;&nbsp; <A class=foot4 id=wl_skip title="Website language translation" href="javascript:doTranslate();">Translations</A> <IMG height=1 alt=" " src="../assets/templates/13/img/dot.gif" width=5 border=0>|<IMG height=1 alt=" " src="../assets/templates/13/img/dot.gif" width=5 border=0> <A class=foot4 title=acessibility href="http://dc.gov/accessibility.asp" target=_parent>Accessibility</A> <IMG height=1 alt=" " src="../assets/templates/13/img/dot.gif" width=5 border=0>|<IMG height=1 alt=" " src="../assets/templates/13/img/dot.gif" width=5 border=0> <A class=foot4 title="privacy and security" href="http://dc.gov/privacy.asp" target=_parent>Privacy &amp; Security</A> <IMG height=1 alt=" " src="../assets/templates/13/img/dot.gif" width=5 border=0>|<IMG height=1 alt=" " src="../assets/templates/13/img/dot.gif" width=5 border=0> <A class=foot4 title="terms and conditions" href="http://dc.gov/terms.asp" target=_parent>Terms &amp; Conditions</A> </TD></TR></TBODY></TABLE></TD>
<TD width=1 bgColor=#cccccc><IMG height=1 alt=" " src="../assets/templates/13/img/dot.gif" width=1 border=0><BR></TD>
<TD vAlign=top width=187><IMG height=1 alt=" " src="../assets/templates/13/img/dot.gif" width=187 border=0><BR>
<TABLE cellSpacing=0 cellPadding=2 border=0 summmary="the address of the John A. Wilson building">
<TBODY>
<TR>
<TD><IMG height=1 alt=" " src="../assets/templates/13/img/dot.gif" width=5 border=0><BR></TD>
<TD><SPAN class=foot1>
<SCRIPT language=JavaScript>document.write('John A. Wilson Building<br>1350 Pennsylvania Avenue, NW<br>Washington, DC 20004')</SCRIPT>
</SPAN></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE></TD>
<TR></TR></TBODY></TABLE>
<TABLE cellSpacing=0 cellPadding=0 width="100%" border=0>
<TBODY>
<TR>
<TD width=10><IMG height=1 alt="" src="../assets/templates/13/img/dot.gif" width=10 border=0></TD>
<TD>
<TABLE cellSpacing=0 cellPadding=0 width="100%" summary="graphical line" border=0>
<TBODY>
<TR>
<TD bgColor=#cccccc height=1><IMG height=1 alt=- src="../assets/templates/13/img/dot.gif" width=1 border=0><BR></TD></TR></TBODY></TABLE></TD></TR></TBODY></TABLE>
<br><!--startindex--><meta NAME="Title" Content="Department of Employment Services: Monthly WARN Notification Log"><meta NAME="DocTitle" Content="Department of Employment Services: Monthly WARN Notification Log"><meta NAME="Description" Content="Monthly WARN Notification Log  Abstract: DEPARTMENT OF EMPLOYMENT SERVICES            WORKFORCE DEVELOPMENT BUREAU         Worker Adjustment and Retraining Notice (WARN) Log Year 2003              MONTHLY WARN NOTIFICATION LOG                   CALENDAR YEAR 2003  Notice  DateCompany/OrganizationNumber of  Employees  AffectedEffective DateType* ..."><meta NAME="Date" Content="2003-11-19">
	
	<!-- DSF: PROPER END OF PAGE -->
		


<!--FROM 193 - Page time: 78 ms</font> -->

	</DSFFOOTER>
	</body>
</html>
